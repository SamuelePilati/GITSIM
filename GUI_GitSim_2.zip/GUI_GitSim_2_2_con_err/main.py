# Public imports
import sys
import os
from PySide6.QtWidgets import QApplication
from PySide6.QtWidgets import QApplication

# Private imports (shared)
from shared.mainwindow import MainWindow
from shared.telegram_manager import TelegramManager
from shared.encoder_data import EncoderData

# Private imports (exclusive)
from tabs.home.serial_box import SerialBox
from tabs.measurement.encoder_measure import EncoderMeasurementBox
from tabs.measurement.set_single_value import SetSingleValue
from tabs.emulation.curve_emulation import CurveEmulation
    
if __name__ == "__main__":
    
    # Initialize shared resources
    # creo istanze delle seguenti classi
    app = QApplication(sys.argv)
    telegram_manager = TelegramManager()
    window = MainWindow()
    encoder_data = EncoderData()
    


    #Codice necessario per generare un'applicazione come file .exe

    # Ottieni il percorso di base corretto
    if getattr(sys, 'frozen', False):
        # Se è in esecuzione come eseguibile PyInstaller
        base_path = sys._MEIPASS                                    
    else:
        # Se è in esecuzione come script Python
        base_path = os.path.dirname(os.path.abspath(__file__))      

    # Percorso completo del file 'style.qss'
    style_path = os.path.join(base_path, 'style.qss')               
    
    ###

    

    # Load the style file
    with open(style_path, "r") as style_file:  #viene aperto il file style.qss in modalità lettura: è un file che descrive lo stile dell'appliazione
        style_str = style_file.read()           #il contenuto del file viene letto e salvato in una variabile
    app.setStyleSheet(style_str)                #lo stile del file viene applicato all'applicazione
    

    # Single resources modules
    # creo istanze delle seguenti classi: ogniuna rappresenta una tab o una funzione dell'applicazione

    # La funzione SerialBox() importata da tab sfrutta classi importate da shared
    # La  stessa cosa avviene per le altre funzioni che vengono richiamate qui sotto2
    serial_connection_tab = SerialBox(window, 
                                      telegram_manager, 
                                      encoder_data) 
    encoder_measure_box = EncoderMeasurementBox(window, 
                                                telegram_manager,
                                                encoder_data)
    set_single_value_box = SetSingleValue(window, 
                                          telegram_manager, 
                                          encoder_data)
    curve_emulation_tab = CurveEmulation(window, 
                                          telegram_manager, 
                                          encoder_data)
    
    # UI loop
    window.show() #mostra la finestra principale all'utente

    sys.exit(app.exec()) #avvia il loop dell'applicazione fino  alla chiusura.
