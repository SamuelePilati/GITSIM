# Resources used
### Credit is due for the following:

App building: [Qt](https://doc.qt.io/qtforpython-6/)
Icon: [flaticon.com](https://www.flaticon.com/free-icons/finger)
Icon: [icons8.com](https://icons8.com/icon/51Tr6obvkPgA/question-mark)

> It's possible I may have forgot some attributions, if that's the case: please message me and I will swiftly add them!
